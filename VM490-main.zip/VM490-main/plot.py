import matplotlib.pyplot as plt
import numpy as np

T=[]
V=[]
for i in range(10):
    T.append([])
    V.append([])
log = open("car_log.txt", "r")
lines = log.readlines()
i=0
for line in lines:
    line = line.rstrip("\n")
    if line.isspace():
        continue
    if i%3==0:
        j=int(line)
    if i%3==1:
        T[j].append(float(line))
    if i%3==2:
        V[j].append(float(line))
    i+=1


for i in range(10):
    plt.plot(T[i],V[i],label=i)

plt.title("Velocity of vehicles under MSO",fontsize=15)
plt.xlabel("T",fontsize=13)
plt.ylabel("V",fontsize=13)
plt.legend()
plt.show()
