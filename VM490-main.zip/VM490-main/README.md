# VM490
 JI VM490 project about SUMO simulation on smart intersections
