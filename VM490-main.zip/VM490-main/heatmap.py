import numpy as np

import matplotlib.pyplot as plt
from pandas import Int8Dtype
import seaborn as sns

ticklabels = [i / 10 for i in range(10+1)]
timesLost=np.loadtxt("LQF_timeloss.txt")
print(timesLost)
ax = sns.heatmap(timesLost, xticklabels = ticklabels, yticklabels = ticklabels[::-1], vmin=0,vmax=10,annot=False,  cmap=plt.get_cmap('RdYlGn_r'),cbar=False)
plt.xlabel("West-to-east demand $\lambda_1$ [veh/sec]",fontsize=16)
plt.ylabel("North-to-south demand $\lambda_2$ [veh/sec]",fontsize=16)
plt.show()